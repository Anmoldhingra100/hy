from django.db import models

# Create your models here.

class Route(models.Model):
    source = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    fare = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.source} to {self.destination} - ₹{self.fare:.2f}"



class BusDepot(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class Bus(models.Model):
    depot = models.ForeignKey(BusDepot, on_delete=models.CASCADE)
    bus_number = models.CharField(max_length=50)
    timing = models.TimeField()

    def __str__(self):
        return f"Bus {self.bus_number} at {self.timing}"





class Student(models.Model):
    name = models.CharField(max_length=100)
    student_id = models.CharField(max_length=20, unique=True)

    def __str__(self):
        return self.name

class Pass(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    pass_type = models.CharField(max_length=50)
    issue_date = models.DateField()
    expiration_date = models.DateField()

    def __str__(self):
        return f'{self.pass_type} for {self.student.name}'


